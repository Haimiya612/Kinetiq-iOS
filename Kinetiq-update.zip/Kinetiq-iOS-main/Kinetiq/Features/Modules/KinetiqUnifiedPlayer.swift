import SwiftUI
import UIKit

// MARK: - Unified visual layer
//
// The renderer is deliberately independent of AVPlayer and module/networking
// objects. Local and remote playback adapters both drive this same interface.
// Every visible action is forwarded to the active playback engine.

enum KinetiqPlayerChromeStyle: String, CaseIterable, Identifiable {
    case signature = "Signature"
    case cinema = "Cinema"
    case focus = "Focus"
    case studio = "Studio"
    case minimal = "Minimal"
    case classic = "Classic"
    case immersive = "Immersive"
    case modern = "Modern"
    var id: String { rawValue }
    static let storageKey = "kinetiq.player.m05.chromeStyle"
    var detail: String {
        switch self {
        case .signature: "The complete M04 player with familiar controls"
        case .cinema: "Letterbox-inspired controls at the edges, no centre console"
        case .focus: "A single centre action and an almost invisible bottom scrubber"
        case .studio: "Compact monitor, timecode and editor-inspired bottom dock"
        case .minimal: "Gesture-friendly floating play, slim timeline and tools menu"
        case .classic: "Traditional transport controls with a separate control strip"
        case .immersive: "Soft glass islands, floating controls and airy spacing"
        case .modern: "Streaming-style bottom command bar with a clear hierarchy"
        }
    }
}

@MainActor
struct KinetiqPlayerAppearancePicker: View {
    @AppStorage(KinetiqPlayerChromeStyle.storageKey)
    private var selectedStyle = KinetiqPlayerChromeStyle.signature.rawValue

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Choose your player")
                .font(.headline)
            Text("Tap a preview to apply it instantly to the local and module player.")
                .font(.caption).foregroundStyle(.secondary)
            ForEach(KinetiqPlayerChromeStyle.allCases) { style in
                Button {
                    selectedStyle = style.rawValue
                    UISelectionFeedbackGenerator().selectionChanged()
                } label: {
                    HStack(spacing: 14) {
                        appearancePreview(style)
                        VStack(alignment: .leading, spacing: 5) {
                            Text(style.rawValue).font(.subheadline.weight(.bold))
                            Text(style.detail).font(.caption2).fixedSize(horizontal: false, vertical: true)
                                .foregroundStyle(.secondary)
                        }
                        Spacer(minLength: 0)
                        if selectedStyle == style.rawValue {
                            Image(systemName: "checkmark.circle.fill").foregroundStyle(.cyan)
                        }
                    }
                    .padding(10)
                    .background(selectedStyle == style.rawValue ? Color.cyan.opacity(0.1) :
                        Color.secondary.opacity(0.08), in: RoundedRectangle(cornerRadius: 13))
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Use \(style.rawValue) player appearance")
            }
        }
    }

    private func appearancePreview(_ style: KinetiqPlayerChromeStyle) -> some View {
        ZStack {
            RoundedRectangle(cornerRadius: 10)
                .fill(LinearGradient(colors: style == .studio ?
                    [.init(red: 0.04, green: 0.18, blue: 0.22), .black] :
                    style == .cinema ? [.black, .init(red: 0.18, green: 0.09, blue: 0.04)] :
                    [.init(red: 0.14, green: 0.20, blue: 0.28), .black],
                    startPoint: .topLeading, endPoint: .bottomTrailing))
            previewContents(style)
                .foregroundStyle(.white)
                .padding(9)
        }
        .frame(width: 138, height: 86)
        .accessibilityHidden(true)
    }

    @ViewBuilder
    private func previewContents(_ style: KinetiqPlayerChromeStyle) -> some View {
        switch style {
        case .signature:
            VStack {
                Text("NOW PLAYING").font(.system(size: 6, weight: .bold))
                Spacer()
                HStack(spacing: 11) {
                    Image(systemName: "gobackward.10")
                    Image(systemName: "pause.fill").font(.title3)
                    Image(systemName: "goforward.10")
                }
                Spacer()
                previewTrack
            }
        case .cinema:
            VStack {
                HStack { Text("CINEMA"); Spacer(); Image(systemName: "film") }
                    .font(.system(size: 7, weight: .medium, design: .serif))
                Spacer()
                HStack { Image(systemName: "gobackward.10"); Spacer(); Image(systemName: "pause.fill"); Spacer(); Image(systemName: "goforward.10") }
                previewTrack
            }
        case .focus:
            VStack {
                HStack { Image(systemName: "chevron.down"); Spacer(); Text("FOCUS").font(.system(size: 7)) }
                Spacer()
                Image(systemName: "pause.circle").font(.system(size: 31, weight: .ultraLight))
                Spacer()
                previewTrack
            }
        case .studio:
            VStack(alignment: .leading, spacing: 5) {
                HStack { Image(systemName: "waveform.path"); Text("MONITOR A"); Spacer(); Text("01:23") }
                    .font(.system(size: 7, design: .monospaced)).foregroundStyle(.cyan)
                Spacer()
                Rectangle().fill(.cyan.opacity(0.28)).frame(height: 1)
                previewTrack
                HStack { Image(systemName: "backward.end.fill"); Spacer(); Image(systemName: "pause.fill"); Spacer(); Image(systemName: "forward.end.fill"); Spacer(); Image(systemName: "slider.horizontal.3") }
                    .font(.system(size: 10))
            }
        case .minimal:
            VStack {
                HStack { Image(systemName: "xmark"); Spacer(); Image(systemName: "ellipsis") }
                Spacer()
                Image(systemName: "pause.fill").font(.system(size: 16))
                Spacer()
                previewTrack
            }
        case .classic:
            VStack {
                HStack { Image(systemName: "chevron.down"); Text("CLASSIC"); Spacer() }
                    .font(.system(size: 8))
                Spacer()
                HStack(spacing: 6) { Image(systemName: "backward.end.fill"); Image(systemName: "pause.fill"); Image(systemName: "forward.end.fill") }
                .padding(5).background(.white.opacity(0.14), in: RoundedRectangle(cornerRadius: 4))
                Spacer()
                previewTrack
            }
        case .immersive:
            VStack {
                HStack { Text("IMMERSIVE"); Spacer(); Image(systemName: "pip") }
                    .font(.system(size: 7))
                Spacer()
                Image(systemName: "pause.circle.fill").font(.system(size: 24))
                Spacer()
                HStack { Image(systemName: "gobackward.10"); Spacer(); Image(systemName: "ellipsis"); Spacer(); Image(systemName: "goforward.10") }
                    .padding(3).background(.white.opacity(0.18), in: Capsule())
                previewTrack
            }
        case .modern:
            VStack(alignment: .leading) {
                Text("UP NEXT").font(.system(size: 7, weight: .bold))
                Spacer()
                previewTrack
                HStack { Image(systemName: "pause.fill"); Image(systemName: "gobackward.10"); Spacer(); Image(systemName: "forward.end.fill"); Image(systemName: "ellipsis") }
                    .padding(5).background(.white.opacity(0.16), in: RoundedRectangle(cornerRadius: 6))
            }
        }
    }

    private var previewTrack: some View {
        Capsule().fill(.white.opacity(0.33)).frame(height: 3)
            .overlay(alignment: .leading) {
                Capsule().fill(.cyan).frame(width: 36, height: 3)
            }
    }
}

@MainActor
struct KinetiqPlayerAppearanceSettingsView: View {
    var body: some View {
        ScrollView {
            KinetiqPlayerAppearancePicker().padding(18)
        }
        .navigationTitle("Player appearance")
        .navigationBarTitleDisplayMode(.inline)
    }
}

@MainActor
struct KinetiqUnifiedPlayerChrome: View {
    struct Panel: Identifiable {
        let id: String
        let symbol: String
        let selected: Bool
    }

    @AppStorage(KinetiqVisualTheme.storageKey)
    private var themeRaw = KinetiqVisualTheme.signature.rawValue
    @AppStorage(KinetiqPlayerChromeStyle.storageKey)
    private var chromeStyleRaw = KinetiqPlayerChromeStyle.signature.rawValue
    private var chromeStyle: KinetiqPlayerChromeStyle {
        KinetiqPlayerChromeStyle(rawValue: chromeStyleRaw) ?? .signature
    }
    private var theme: KinetiqVisualTheme {
        KinetiqVisualTheme(rawValue: themeRaw) ?? .signature
    }
    private var playerAccent: Color {
        theme == .signature ? KinetiqPalette.cyan : theme.accent
    }
    let safeAreaInsets: EdgeInsets
    let title: String
    let playing: Bool
    let busy: Bool
    let aspectFill: Bool
    let pictureInPictureAvailable: Bool
    let displayedTime: Double
    let duration: Double
    let elapsedLabel: String
    let durationLabel: String
    let panels: [Panel]
    let airPlayControl: AnyView

    let onClose: () -> Void
    let onStartPictureInPicture: () -> Void
    /// The module player exposes its safety lock in the header; local playback
    /// leaves this nil and retains its established controls.
    let onLockControls: (() -> Void)?
    let onToggleAspect: () -> Void
    let onPrevious: () -> Void
    let onRewind: () -> Void
    let onTogglePlay: () -> Void
    let onForward: () -> Void
    let onNext: () -> Void
    let onSeekChanged: (Double) -> Void
    let onSeekEditingChanged: (Bool) -> Void
    let onPanelSelected: (String) -> Void

    /// Explicitly define the shared chrome's API so that Swift's synthesized
    /// memberwise initializer cannot omit the optional Lock handler.
    init(
        safeAreaInsets: EdgeInsets,
        title: String,
        playing: Bool,
        busy: Bool,
        aspectFill: Bool,
        pictureInPictureAvailable: Bool,
        displayedTime: Double,
        duration: Double,
        elapsedLabel: String,
        durationLabel: String,
        panels: [Panel],
        airPlayControl: AnyView,
        onClose: @escaping () -> Void,
        onStartPictureInPicture: @escaping () -> Void,
        onLockControls: (() -> Void)?,
        onToggleAspect: @escaping () -> Void,
        onPrevious: @escaping () -> Void,
        onRewind: @escaping () -> Void,
        onTogglePlay: @escaping () -> Void,
        onForward: @escaping () -> Void,
        onNext: @escaping () -> Void,
        onSeekChanged: @escaping (Double) -> Void,
        onSeekEditingChanged: @escaping (Bool) -> Void,
        onPanelSelected: @escaping (String) -> Void
    ) {
        self.safeAreaInsets = safeAreaInsets
        self.title = title
        self.playing = playing
        self.busy = busy
        self.aspectFill = aspectFill
        self.pictureInPictureAvailable = pictureInPictureAvailable
        self.displayedTime = displayedTime
        self.duration = duration
        self.elapsedLabel = elapsedLabel
        self.durationLabel = durationLabel
        self.panels = panels
        self.airPlayControl = airPlayControl
        self.onClose = onClose
        self.onStartPictureInPicture = onStartPictureInPicture
        self.onLockControls = onLockControls
        self.onToggleAspect = onToggleAspect
        self.onPrevious = onPrevious
        self.onRewind = onRewind
        self.onTogglePlay = onTogglePlay
        self.onForward = onForward
        self.onNext = onNext
        self.onSeekChanged = onSeekChanged
        self.onSeekEditingChanged = onSeekEditingChanged
        self.onPanelSelected = onPanelSelected
    }

    var body: some View {
        Group {
            if chromeStyle == .signature {
                signatureChrome
            } else {
                GeometryReader { geometry in
                    redesignedChrome(isPortrait: geometry.size.height > geometry.size.width)
                }
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }

    // Signature is the exact original layout and tap map. Keep every visual
    // adjustment to the other appearance branches, not this baseline.
    private var signatureChrome: some View {
        ZStack {
            LinearGradient(
                stops: [
                    .init(color: .black.opacity(chromeStyle == .cinema ? 0.86 : 0.58), location: 0),
                    .init(color: .clear, location: 0.27),
                    .init(color: .clear, location: 0.60),
                    .init(color: .black.opacity(chromeStyle == .focus ? 0.86 : 0.70), location: 1)
                ],
                startPoint: .top,
                endPoint: .bottom
            )
            .allowsHitTesting(false)

            VStack(spacing: 0) {
                header
                    .padding(.top, max(safeAreaInsets.top, 14))
                Spacer(minLength: 18)
                transport
                    .opacity(chromeStyle == .focus ? 0.76 : 1)
                Spacer(minLength: 18)
                footer
                    .opacity(chromeStyle == .focus ? 0.73 : 1)
                    .padding(.bottom, max(safeAreaInsets.bottom, 15))
            }
            .padding(.horizontal, 16)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }

    @ViewBuilder
    private func redesignedChrome(isPortrait: Bool) -> some View {
        switch chromeStyle {
        case .cinema: cinemaChrome(isPortrait: isPortrait)
        case .focus: focusChrome(isPortrait: isPortrait)
        case .studio: studioChrome(isPortrait: isPortrait)
        case .minimal: minimalChrome(isPortrait: isPortrait)
        case .classic: classicChrome(isPortrait: isPortrait)
        case .immersive: immersiveChrome(isPortrait: isPortrait)
        case .modern: modernChrome(isPortrait: isPortrait)
        case .signature: signatureChrome
        }
    }

    /// Every redesigned appearance uses an independent, portrait-safe header.
    /// The original Signature header is intentionally left unchanged.
    @ViewBuilder
    private func redesignedHeader(isPortrait: Bool) -> some View {
        if isPortrait {
            VStack(alignment: .leading, spacing: 9) {
                HStack(spacing: 10) {
                    headerButton("chevron.down", label: "Close player", size: 15, action: onClose)
                    Text(title)
                        .font(.subheadline.weight(.semibold))
                        .lineLimit(1)
                        .foregroundStyle(.white)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                HStack(spacing: 12) {
                    Spacer()
                    if let onLockControls {
                        headerButton("lock", label: "Lock controls", size: 15, action: onLockControls)
                    }
                    airPlayControl.frame(width: 40, height: 40)
                        .accessibilityLabel("AirPlay")
                    if pictureInPictureAvailable {
                        headerButton("pip", label: "Picture in Picture", size: 15,
                                     action: onStartPictureInPicture)
                    }
                    headerButton(aspectFill ? "arrow.down.right.and.arrow.up.left" :
                                 "arrow.up.left.and.arrow.down.right",
                                 label: aspectFill ? "Fit video" : "Fill screen",
                                 size: 14, action: onToggleAspect)
                }
            }
            // The immersive hosting GeometryReader can report top inset 0.
            // Reserve a real status bar row in portrait rather than drawing
            // the title and lock/AirPlay/PiP buttons under the clock.
            .padding(.top, max(safeAreaInsets.top, 62))
        } else {
            header.padding(.top, max(safeAreaInsets.top, 12))
        }
    }

    private func cinemaChrome(isPortrait: Bool) -> some View {
        ZStack {
            LinearGradient(colors: [.black.opacity(0.40), .clear, .clear, .black.opacity(0.72)],
                           startPoint: .top, endPoint: .bottom).allowsHitTesting(false)
            VStack(spacing: 0) {
                floatingTitle(isPortrait: isPortrait, eyebrow: "CINEMA • NOW SHOWING", color: .orange)
                Spacer(minLength: 10)
                HStack(spacing: 15) {
                    transportButton("gobackward.10", size: 20, width: 42,
                                    label: "Back 10 seconds", action: onRewind)
                    Spacer(minLength: 0)
                    compactPlay(size: 52, circle: true)
                    Spacer(minLength: 0)
                    transportButton("goforward.10", size: 20, width: 42,
                                    label: "Forward 10 seconds", action: onForward)
                }
                .frame(maxWidth: 350)
                VStack(spacing: 6) {
                    compactTimeline
                    HStack {
                        Button("Previous", systemImage: "backward.end.fill", action: onPrevious)
                        Spacer()
                        Image(systemName: "film.stack").foregroundStyle(.orange)
                        Text("THEATRE").tracking(2)
                            .font(.system(size: 10, weight: .medium, design: .serif))
                        Spacer()
                        Button("Next", systemImage: "forward.end.fill", action: onNext)
                    }
                    .labelStyle(.iconOnly)
                    .font(.system(size: 15))
                    HStack {
                        Spacer()
                        toolsMenu
                    }
                }
                .foregroundStyle(.white)
                .padding(.bottom, max(safeAreaInsets.bottom, 8))
            }
            .padding(.horizontal, isPortrait ? 20 : 35)
        }
    }

    private func focusChrome(isPortrait: Bool) -> some View {
        ZStack {
            LinearGradient(colors: [.black.opacity(0.23), .clear, .black.opacity(0.39)],
                           startPoint: .top, endPoint: .bottom).allowsHitTesting(false)
            VStack(spacing: 0) {
                floatingTitle(isPortrait: isPortrait, eyebrow: "FOCUS", color: .white)
                Spacer(minLength: 10)
                compactPlay(size: 76, circle: true)
                Spacer(minLength: 10)
                compactTimeline
                HStack(spacing: 18) {
                    transportButton("gobackward.10", size: 17, width: 44,
                                    label: "Back 10 seconds", action: onRewind)
                    transportButton("goforward.10", size: 17, width: 44,
                                    label: "Forward 10 seconds", action: onForward)
                    Spacer()
                    toolsMenu
                }
                .foregroundStyle(.white.opacity(0.85))
                .padding(.bottom, max(safeAreaInsets.bottom, 8))
            }
            .padding(.horizontal, isPortrait ? 20 : 34)
        }
    }

    private func studioChrome(isPortrait: Bool) -> some View {
        ZStack {
            LinearGradient(colors: [.black.opacity(0.42), .clear, .black.opacity(0.58)],
                           startPoint: .top, endPoint: .bottom).allowsHitTesting(false)
            VStack(spacing: 0) {
                floatingTitle(isPortrait: isPortrait, eyebrow: "STUDIO • MONITOR A", color: .cyan)
                HStack(spacing: 10) {
                    Label("LIVE MONITOR", systemImage: "waveform.path")
                    Spacer()
                    Text("\(elapsedLabel) / \(durationLabel)")
                }
                .font(.system(size: 10, weight: .semibold, design: .monospaced))
                .foregroundStyle(.cyan)
                .padding(.vertical, 8)
                Spacer(minLength: 10)
                VStack(spacing: 4) {
                    HStack(spacing: 5) {
                        Label("PLAYBACK TIMELINE", systemImage: "film.stack")
                        Spacer()
                        Text(playing ? "PLAY" : "PAUSED")
                    }
                    .font(.system(size: 9, weight: .bold, design: .monospaced))
                    .foregroundStyle(.cyan)
                    compactTimeline
                    HStack(spacing: 5) {
                        transportButton("backward.end.fill", size: 16, width: 38,
                                        label: "Previous", action: onPrevious)
                        transportButton("gobackward.10", size: 18, width: 42,
                                        label: "Back 10 seconds", action: onRewind)
                        compactPlay(size: 47, circle: false)
                        transportButton("goforward.10", size: 18, width: 42,
                                        label: "Forward 10 seconds", action: onForward)
                        transportButton("forward.end.fill", size: 16, width: 38,
                                        label: "Next", action: onNext)
                        Spacer(minLength: 2)
                        toolsMenu
                    }
                    .foregroundStyle(.white)
                    compactPanelRail
                }
                .padding(10)
                .background(Color.black.opacity(0.60),
                            in: RoundedRectangle(cornerRadius: 12))
                .overlay(RoundedRectangle(cornerRadius: 12).strokeBorder(.cyan.opacity(0.26)))
                .padding(.bottom, max(safeAreaInsets.bottom, 8))
            }
            .padding(.horizontal, isPortrait ? 12 : 20)
        }
    }

    private func minimalChrome(isPortrait: Bool) -> some View {
        ZStack {
            LinearGradient(colors: [.black.opacity(0.16), .clear, .black.opacity(0.34)],
                           startPoint: .top, endPoint: .bottom).allowsHitTesting(false)
            VStack(spacing: 0) {
                HStack {
                    headerButton("xmark", label: "Close player", size: 12, action: onClose)
                    Spacer()
                    toolsMenu
                }
                .padding(.top, max(safeAreaInsets.top, isPortrait ? 62 : 12))
                Spacer(minLength: 10)
                compactPlay(size: 58, circle: true)
                Spacer(minLength: 10)
                HStack {
                    Text(title).lineLimit(1).font(.caption.weight(.medium))
                    Spacer()
                    Text(elapsedLabel).font(.caption.monospacedDigit())
                }
                .foregroundStyle(.white.opacity(0.85))
                compactTimeline
                .padding(.bottom, max(safeAreaInsets.bottom, 9))
            }
            .padding(.horizontal, isPortrait ? 18 : 26)
        }
    }

    private func classicChrome(isPortrait: Bool) -> some View {
        ZStack {
            LinearGradient(colors: [.black.opacity(0.48), .clear, .black.opacity(0.68)],
                           startPoint: .top, endPoint: .bottom).allowsHitTesting(false)
            VStack(spacing: 0) {
                redesignedHeader(isPortrait: isPortrait)
                Spacer(minLength: 10)
                Text(playing ? "Playing" : "Paused")
                    .font(.system(size: 12, weight: .semibold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.9))
                transport
                    .scaleEffect(0.92)
                Spacer(minLength: 12)
                VStack(spacing: 7) {
                    compactTimeline
                    compactPanelRail
                }
                .padding(10)
                .background(Color(white: 0.12).opacity(0.79))
                .padding(.bottom, max(safeAreaInsets.bottom, 8))
            }
            .padding(.horizontal, isPortrait ? 12 : 18)
        }
    }

    private func immersiveChrome(isPortrait: Bool) -> some View {
        ZStack {
            LinearGradient(colors: [.black.opacity(0.24), .clear, .black.opacity(0.49)],
                           startPoint: .top, endPoint: .bottom).allowsHitTesting(false)
            VStack(spacing: 0) {
                floatingTitle(isPortrait: isPortrait, eyebrow: "IMMERSIVE", color: .mint)
                Spacer(minLength: 8)
                compactPlay(size: 64, circle: true)
                    .background(.ultraThinMaterial, in: Circle())
                Spacer(minLength: 8)
                HStack(spacing: 12) {
                    transportButton("gobackward.10", size: 18, width: 42,
                                    label: "Back 10 seconds", action: onRewind)
                    Spacer(minLength: 0)
                    toolsMenu
                    Spacer(minLength: 0)
                    transportButton("goforward.10", size: 18, width: 42,
                                    label: "Forward 10 seconds", action: onForward)
                }
                .foregroundStyle(.white)
                .padding(.horizontal, 16)
                .background(.ultraThinMaterial, in: Capsule())
                compactTimeline
                    .padding(.top, 8)
                    .padding(.bottom, max(safeAreaInsets.bottom, 8))
            }
            .padding(.horizontal, isPortrait ? 20 : 32)
        }
    }

    private func modernChrome(isPortrait: Bool) -> some View {
        ZStack {
            LinearGradient(colors: [.black.opacity(0.26), .clear, .black.opacity(0.65)],
                           startPoint: .top, endPoint: .bottom).allowsHitTesting(false)
            VStack(spacing: 0) {
                floatingTitle(isPortrait: isPortrait, eyebrow: "UP NEXT • KINETIQ", color: playerAccent)
                Spacer(minLength: 8)
                VStack(spacing: 8) {
                    compactTimeline
                    HStack(spacing: 8) {
                        compactPlay(size: 52, circle: false)
                        transportButton("gobackward.10", size: 19, width: 42,
                                        label: "Back 10 seconds", action: onRewind)
                        transportButton("goforward.10", size: 19, width: 42,
                                        label: "Forward 10 seconds", action: onForward)
                        Spacer(minLength: 0)
                        Button("Next", systemImage: "forward.end.fill", action: onNext)
                            .labelStyle(.iconOnly)
                        toolsMenu
                    }
                    .foregroundStyle(.white)
                }
                .padding(12)
                .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 18))
                .padding(.bottom, max(safeAreaInsets.bottom, 8))
            }
            .padding(.horizontal, isPortrait ? 12 : 24)
        }
    }

    private func floatingTitle(isPortrait: Bool, eyebrow: String, color: Color) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 10) {
                headerButton("chevron.down", label: "Close player", size: 15, action: onClose)
                VStack(alignment: .leading, spacing: 2) {
                    Text(eyebrow).font(.system(size: 9, weight: .semibold))
                        .tracking(1.5).foregroundStyle(color)
                    Text(title).font(.subheadline.weight(.medium))
                        .lineLimit(1).foregroundStyle(.white)
                }
                Spacer(minLength: 0)
                if !isPortrait { quickActions }
            }
            if isPortrait {
                HStack {
                    Spacer()
                    quickActions
                }
            }
        }
        .padding(.top, max(safeAreaInsets.top, isPortrait ? 62 : 12))
    }

    private var quickActions: some View {
        HStack(spacing: 6) {
            if let onLockControls {
                headerButton("lock", label: "Lock controls", size: 14, action: onLockControls)
            }
            airPlayControl.frame(width: 40, height: 40).accessibilityLabel("AirPlay")
            if pictureInPictureAvailable {
                headerButton("pip", label: "Picture in Picture", size: 14,
                             action: onStartPictureInPicture)
            }
            headerButton(aspectFill ? "arrow.down.right.and.arrow.up.left" :
                         "arrow.up.left.and.arrow.down.right",
                         label: aspectFill ? "Fit video" : "Fill screen", size: 14,
                         action: onToggleAspect)
        }
    }

    private func compactPlay(size: CGFloat, circle: Bool) -> some View {
        Button(action: onTogglePlay) {
            Image(systemName: playing ? "pause.fill" : "play.fill")
                .font(.system(size: size * 0.39, weight: .semibold))
                .foregroundStyle(.white)
                .contentTransition(.symbolEffect(.replace))
                .frame(width: size, height: size)
                .background(.black.opacity(0.49),
                            in: RoundedRectangle(cornerRadius: circle ? size / 2 : 13))
                .overlay(RoundedRectangle(cornerRadius: circle ? size / 2 : 13)
                    .strokeBorder(.white.opacity(0.24), lineWidth: 0.8))
        }
        .buttonStyle(.plain)
        .disabled(busy)
        .accessibilityLabel(playing ? "Pause" : "Play")
    }

    private var compactTimeline: some View {
        VStack(spacing: 2) {
            Slider(
                value: Binding(
                    get: { min(max(displayedTime.isFinite ? displayedTime : 0, 0),
                               max(duration.isFinite ? duration : 1, 1)) },
                    set: { onSeekChanged($0) }
                ),
                in: 0...max(duration.isFinite ? duration : 1, 1),
                onEditingChanged: onSeekEditingChanged
            )
            .tint(playerAccent)
            .accessibilityLabel("Playback position")
            HStack {
                Text(elapsedLabel)
                Spacer()
                Text(durationLabel)
            }
            .font(.system(size: 10, weight: .medium, design: .monospaced))
            .foregroundStyle(.white.opacity(0.85))
        }
    }

    private var compactPanelRail: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 9) {
                ForEach(panels) { panel in
                    Button {
                        onPanelSelected(panel.id)
                    } label: {
                        Label(panel.id, systemImage: panel.symbol)
                            .font(.system(size: 11, weight: .medium))
                            .foregroundStyle(panel.selected ? playerAccent : .white)
                            .padding(.horizontal, 9).padding(.vertical, 7)
                            .background(.white.opacity(0.09), in: Capsule())
                    }
                    .buttonStyle(.plain)
                }
            }
        }
        .accessibilityLabel("Player tools")
    }

    private var toolsMenu: some View {
        Menu {
            Section("Transport") {
                Button("Previous episode", systemImage: "backward.end.fill", action: onPrevious)
                Button("Next episode", systemImage: "forward.end.fill", action: onNext)
                Button("Back 10 seconds", systemImage: "gobackward.10", action: onRewind)
                Button("Forward 10 seconds", systemImage: "goforward.10", action: onForward)
            }
            Section("Player options") {
                ForEach(panels) { panel in
                    Button(panel.id, systemImage: panel.symbol) { onPanelSelected(panel.id) }
                }
            }
            if let onLockControls {
                Button("Lock controls", systemImage: "lock", action: onLockControls)
            }
            if pictureInPictureAvailable {
                Button("Picture in Picture", systemImage: "pip", action: onStartPictureInPicture)
            }
            Button(aspectFill ? "Fit video" : "Fill screen",
                   systemImage: "arrow.up.left.and.arrow.down.right", action: onToggleAspect)
        } label: {
            Image(systemName: "ellipsis.circle.fill")
                .font(.system(size: 23))
                .foregroundStyle(.white)
                .frame(width: 44, height: 44)
                .contentShape(Rectangle())
        }
        .accessibilityLabel("Player tools and settings")
    }

    private var heroPlayButton: some View {
        Button(action: onTogglePlay) {
            Image(systemName: playing ? "pause.fill" : "play.fill")
                .font(.system(size: 33, weight: .bold))
                .foregroundStyle(.white)
                .frame(width: 90, height: 90)
                .background(.black.opacity(0.38), in: Circle())
                .overlay(Circle().strokeBorder(.white.opacity(0.25), lineWidth: 1))
        }
        .buttonStyle(.plain)
        .disabled(busy)
        .accessibilityLabel(playing ? "Pause" : "Play")
    }

    private var secondaryTransport: some View {
        HStack(spacing: 16) {
            transportButton("backward.end.fill", size: 18, width: 42,
                            label: "Previous", action: onPrevious)
            transportButton("gobackward.10", size: 22, width: 48,
                            label: "Back 10 seconds", action: onRewind)
            Spacer(minLength: 0)
            transportButton("goforward.10", size: 22, width: 48,
                            label: "Forward 10 seconds", action: onForward)
            transportButton("forward.end.fill", size: 18, width: 42,
                            label: "Next", action: onNext)
        }
        .buttonStyle(.plain)
        .disabled(busy)
        .foregroundStyle(.white)
    }

    private var header: some View {
        HStack(spacing: 11) {
            headerButton("chevron.down", label: "Close player", size: 15, action: onClose)
                .frame(width: 42, height: 42)

            VStack(alignment: .leading, spacing: 3) {
                Text(theme == .cinema ? "NOW SHOWING" :
                     theme == .anime ? "ANIME PULSE" :
                     theme == .aurora ? "YOUR STREAM" :
                     theme == .nocturne ? "FOCUS MODE" : "NOW PLAYING")
                    .font(.system(size: 9, weight: .bold, design: .rounded))
                    .tracking(1.8)
                    .foregroundStyle(playerAccent)

                Text(title)
                    .font(.system(size: theme == .cinema ? 16 : 14,
                                  weight: .semibold,
                                  design: theme == .cinema ? .serif : .rounded))
                    .foregroundStyle(.white)
                    .lineLimit(1)
            }

            Spacer(minLength: 4)

            if let onLockControls {
                headerButton("lock", label: "Lock player controls", size: 15,
                             action: onLockControls)
            }

            airPlayControl
                .frame(width: 40, height: 40)
                .background {
                    if chromeStyle == .cinema || theme == .cinema || theme == .nocturne {
                        RoundedRectangle(cornerRadius: 9)
                            .fill(.black.opacity(0.68))
                    } else {
                        Circle().fill(.black.opacity(0.34))
                    }
                }
                .overlay {
                    if theme == .anime {
                        Circle().strokeBorder(playerAccent.opacity(0.5), lineWidth: 1)
                    }
                }
                .accessibilityLabel("AirPlay")

            if pictureInPictureAvailable {
                headerButton("pip", label: "Start Picture in Picture", size: 15, action: onStartPictureInPicture)
            }

            headerButton(
                aspectFill
                    ? "arrow.down.right.and.arrow.up.left"
                    : "arrow.up.left.and.arrow.down.right",
                label: aspectFill ? "Fit video to screen" : "Fill screen with video",
                size: 14,
                action: onToggleAspect
            )
        }
    }

    private func headerButton(
        _ symbol: String,
        label: String,
        size: CGFloat,
        action: @escaping () -> Void
    ) -> some View {
        Button(action: action) {
            Image(systemName: symbol)
                .font(.system(size: size, weight: .semibold))
                .foregroundStyle(.white)
                .frame(width: 40, height: 40)
                .background {
                    if theme == .cinema || theme == .nocturne {
                        RoundedRectangle(cornerRadius: 9)
                            .fill(.black.opacity(0.68))
                    } else {
                        Circle().fill(.black.opacity(0.34))
                    }
                }
                .overlay {
                    if theme == .anime {
                        Circle().strokeBorder(playerAccent.opacity(0.5), lineWidth: 1)
                    }
                }
        }
        .buttonStyle(.plain)
        .accessibilityLabel(label)
    }

    private var transport: some View {
        HStack(spacing: 13) {
            transportButton("backward.end.fill", size: 18, width: 38,
                            label: "Previous", action: onPrevious)
            transportButton("gobackward.10", size: 25, width: 44,
                            label: "Back 10 seconds", action: onRewind)

            Button(action: onTogglePlay) {
                Image(systemName: playing ? "pause.fill" : "play.fill")
                    .font(.system(size: 25, weight: .bold))
                    .foregroundStyle(.white)
                    .contentTransition(.symbolEffect(.replace))
                    .frame(width: theme == .nocturne ? 64 : 72,
                           height: theme == .nocturne ? 64 : 72)
                    .background {
                        if chromeStyle == .cinema || theme == .cinema {
                            RoundedRectangle(cornerRadius: 12)
                                .fill(.black.opacity(0.82))
                        } else if theme == .anime {
                            Circle().fill(LinearGradient(colors: [
                                theme.accent.opacity(0.86),
                                theme.highlight.opacity(0.77)
                            ], startPoint: .topLeading, endPoint: .bottomTrailing))
                        } else if theme == .nocturne {
                            Circle().fill(.black.opacity(0.66))
                        } else {
                            Circle().fill(.ultraThinMaterial)
                        }
                    }
                    .overlay {
                        if chromeStyle == .cinema || theme == .cinema {
                            RoundedRectangle(cornerRadius: 12)
                                .strokeBorder(.white.opacity(0.3), lineWidth: 1)
                        } else {
                            Circle().strokeBorder(playerAccent.opacity(
                                theme == .anime ? 0.85 : 0.22
                            ), lineWidth: theme == .anime ? 2 : 1)
                        }
                    }
                    .shadow(color: .black.opacity(0.28), radius: 18, y: 7)
            }
            .accessibilityLabel(playing ? "Pause" : "Play")

            transportButton("goforward.10", size: 25, width: 44,
                            label: "Forward 10 seconds", action: onForward)
            transportButton("forward.end.fill", size: 18, width: 38,
                            label: "Next", action: onNext)
        }
        .buttonStyle(.plain)
        .disabled(busy)
        .opacity(busy ? 0.55 : 1)
    }

    private func transportButton(
        _ symbol: String,
        size: CGFloat,
        width: CGFloat,
        label: String,
        action: @escaping () -> Void
    ) -> some View {
        Button(action: action) {
            Image(systemName: symbol)
                .font(.system(size: size, weight: .medium))
                .foregroundStyle(.white)
                .frame(width: width, height: 58)
                .contentShape(Rectangle())
        }
        .accessibilityLabel(label)
    }

    private var footer: some View {
        VStack(spacing: 12) {
            VStack(spacing: 4) {
                Slider(
                    value: Binding(
                        get: { min(max(displayedTime.isFinite ? displayedTime : 0, 0), max(duration, 1)) },
                        set: { onSeekChanged($0) }
                    ),
                    in: 0...max(duration.isFinite ? duration : 1, 1),
                    onEditingChanged: onSeekEditingChanged
                )
                .tint(playerAccent)
                .accessibilityLabel("Playback position")

                HStack {
                    Text(elapsedLabel)
                    Spacer()
                    Text(durationLabel)
                }
                .font(.system(size: 10, weight: .semibold, design: .monospaced))
                .foregroundStyle(.white.opacity(0.88))
            }

            panelBar
        }
    }

    private var panelBar: some View {
        HStack(spacing: 1) {
            ForEach(panels) { panel in
                Button {
                    onPanelSelected(panel.id)
                } label: {
                    VStack(spacing: 5) {
                        Image(systemName: panel.symbol)
                            .font(.system(size: 15, weight: .semibold))
                        Text(panel.id)
                            .font(.system(size: 8, weight: .semibold))
                            .lineLimit(1)
                            .minimumScaleFactor(0.75)
                    }
                    .foregroundStyle(
                        panel.selected
                            ? playerAccent
                            : .white.opacity(theme == .nocturne ? 0.72 : 0.92)
                    )
                    .frame(maxWidth: .infinity)
                    .frame(height: 52)
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .accessibilityLabel(panel.id)
            }
        }
        .padding(.horizontal, 5)
        .padding(.vertical, 5)
        .background {
            if theme == .cinema || theme == .nocturne {
                RoundedRectangle(cornerRadius: theme == .cinema ? 8 : 14)
                    .fill(.black.opacity(theme == .nocturne ? 0.87 : 0.77))
            } else if theme == .anime {
                RoundedRectangle(cornerRadius: 20)
                    .fill(.ultraThinMaterial)
                    .overlay {
                        RoundedRectangle(cornerRadius: 20)
                            .strokeBorder(playerAccent.opacity(0.44), lineWidth: 1)
                    }
            } else {
                Capsule().fill(.ultraThinMaterial)
            }
        }
        .overlay {
            if theme == .cinema || theme == .nocturne {
                RoundedRectangle(cornerRadius: theme == .cinema ? 8 : 14)
                    .strokeBorder(.white.opacity(theme == .cinema ? 0.24 : 0.08), lineWidth: 1)
            }
        }
        .shadow(color: .black.opacity(0.22), radius: theme == .nocturne ? 5 : 16, y: 6)
    }
}

// MARK: - Shared options-sheet frame

@MainActor
struct KinetiqUnifiedPlayerOptionsFrame<Content: View>: View {
    let title: String
    let symbol: String
    let onClose: () -> Void
    @ViewBuilder let content: Content

    init(
        title: String,
        symbol: String,
        onClose: @escaping () -> Void,
        @ViewBuilder content: () -> Content
    ) {
        self.title = title
        self.symbol = symbol
        self.onClose = onClose
        self.content = content()
    }

    var body: some View {
        VStack(spacing: 0) {
            Capsule()
                .fill(.white.opacity(0.35))
                .frame(width: 38, height: 4)
                .padding(.top, 10)
                .padding(.bottom, 16)

            HStack {
                HStack(spacing: 10) {
                    Image(systemName: symbol)
                        .foregroundStyle(KinetiqPalette.cyan)
                    Text(title)
                        .font(.system(size: 17, weight: .bold, design: .rounded))
                        .foregroundStyle(.white)
                }

                Spacer()

                Button(action: onClose) {
                    Image(systemName: "xmark")
                        .font(.system(size: 11, weight: .bold))
                        .foregroundStyle(.white.opacity(0.8))
                        .frame(width: 32, height: 32)
                        .background(.white.opacity(0.10), in: Circle())
                }
                .accessibilityLabel("Close options")
            }
            .padding(.horizontal, 19)
            .padding(.bottom, 14)

            Rectangle()
                .fill(.white.opacity(0.10))
                .frame(height: 1)

            ScrollView {
                VStack(alignment: .leading, spacing: 14) {
                    content
                }
                .padding(18)
            }
            .frame(maxHeight: 390)
        }
        .background(.ultraThinMaterial)
        .background(Color(red: 0.035, green: 0.045, blue: 0.065).opacity(0.90))
        .clipShape(UnevenRoundedRectangle(topLeadingRadius: 24, topTrailingRadius: 24))
        .overlay(alignment: .top) {
            UnevenRoundedRectangle(topLeadingRadius: 24, topTrailingRadius: 24)
                .stroke(.white.opacity(0.13), lineWidth: 1)
        }
        .shadow(color: .black.opacity(0.32), radius: 25, y: -5)
    }
}

// MARK: - Shared playback error presentation

@MainActor
struct KinetiqUnifiedPlayerFailureOverlay: View {
    let message: String
    let onRetry: () -> Void
    let onSkip: () -> Void

    var body: some View {
        VStack(spacing: 12) {
            Image(systemName: "exclamationmark.triangle.fill")
                .font(.system(size: 28))
                .foregroundStyle(.orange)

            Text("Playback issue")
                .font(.headline)
                .foregroundStyle(.white)

            Text(message)
                .font(.caption)
                .foregroundStyle(.white.opacity(0.72))
                .multilineTextAlignment(.center)

            HStack(spacing: 10) {
                Button(action: onRetry) {
                    Label("Try again", systemImage: "arrow.clockwise")
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(.black)
                        .padding(.horizontal, 18)
                        .padding(.vertical, 11)
                        .background(KinetiqPalette.cyan, in: Capsule())
                }
                Button(action: onSkip) {
                    Label("Skip", systemImage: "forward.end.fill")
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 18)
                        .padding(.vertical, 11)
                        .background(.white.opacity(0.13), in: Capsule())
                }
            }
            .padding(.top, 5)
        }
        .padding(24)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 20))
        .overlay(RoundedRectangle(cornerRadius: 20)
            .stroke(.white.opacity(0.12), lineWidth: 1))
        .padding(30)
    }
}
